import org.junit.*;

public class ComplexNumber {

	/* STUDENTS: You may NOT add any further instance or static variables! */
	private final MyDouble real; // To be initialized in constructors
	private final MyDouble imag; // To be initialized in constructors

	public ComplexNumber(MyDouble realIn, MyDouble imagIn) {
		real = realIn;
		imag = imagIn;

	}

	public ComplexNumber(MyDouble realIn) {
		real = realIn;
		imag = new MyDouble(0);
	}

	public ComplexNumber(ComplexNumber other) {
		real = other.real;
		imag = other.imag;
	}

	/* STUDENTS: Put your methods here, as described in the project description. */
//public instance methods
	public MyDouble getReal() {
		return real;
	}

	public MyDouble getImag() {
		return imag;
	}

	public ComplexNumber add(ComplexNumber other) {
		MyDouble mReal = real.add(other.real);
		MyDouble mImag = imag.add(other.imag);

		return new ComplexNumber(mReal, mImag);
	}

	public ComplexNumber subtract(ComplexNumber other) {
		MyDouble mReal = real.subtract(other.real);
		MyDouble mImag = imag.subtract(other.imag);

		return new ComplexNumber(mReal, mImag);
	}

	public ComplexNumber multiply(ComplexNumber other) {
		MyDouble mReal = real.multiply(other.real).subtract(imag.multiply(other.imag));
		MyDouble mImag = real.multiply(other.imag).add(imag.multiply(other.real));

		return new ComplexNumber(mReal, mImag);
	}

	public ComplexNumber divide(ComplexNumber other) {
		MyDouble mReal = (real.multiply(other.real).add(imag.multiply(other.imag)))
				.divide(((other.real.multiply(other.real)).add(other.imag.multiply(other.imag))));
		MyDouble mImag = (imag.multiply(other.real).subtract(real.multiply(other.imag)))
				.divide((other.real.multiply(other.real)).add(other.imag.multiply(other.imag)));
		;
		return new ComplexNumber(mReal, mImag);
	}

	public boolean equals(ComplexNumber other) {
		if (real.equals(other.real) && imag.equals(other.imag)) {
			return true;
		} else {
			return false;
		}
	}

	public int compareTo(ComplexNumber other) {
		MyDouble cNorm = ((real.multiply(real)).add(imag.multiply(imag))).sqrt();
		MyDouble pNorm = ((other.real.multiply(other.real)).add(other.imag.multiply(other.imag))).sqrt();
		return cNorm.compareTo(pNorm);
	}

	public String toString() {
		if (imag.compareTo(new MyDouble(0)) == -1) {
			return (real + "" + imag + "i");
		} else {
			return (real + "+" + imag + "i");
		}
	}

//public static methods

	public static MyDouble norm(ComplexNumber other) {
		MyDouble norm = ((other.real.multiply(other.real)).add(other.imag.multiply(other.imag))).sqrt();
		return norm;
	}

	public static ComplexNumber parseComplexNumber(String str) {
		str = str.replace("i", "");
		str = str.replace(" ", "");
		Boolean negReal = false;
		Boolean negImag = false;
		if (str.charAt(0) == '-') {
			negReal = true;
			str = str.replaceFirst("-", "");
		}
		str = str.replace("-", "+-");
		str = str.replace("+", "/");
		String[] string = str.split("/", 2);
		String str1 = string[0];
		String str2 = string[1];
		if (str2.charAt(0) == '-') {
			negImag = true;
			str2 = str2.replaceFirst("-", "");
		}
		Double doubleOne = Double.parseDouble(str1);
		Double doubleTwo = Double.parseDouble(str2);
		if (negReal == true) {
			doubleOne = doubleOne * -1;
		}
		if (negImag == true) {
			doubleTwo = doubleTwo * -1;
		}
		MyDouble parseOne = new MyDouble(doubleOne);
		MyDouble parseTwo = new MyDouble(doubleTwo);
		return new ComplexNumber(parseOne, parseTwo);

	}
}
