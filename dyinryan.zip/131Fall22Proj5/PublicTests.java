import static org.junit.Assert.*;

import org.junit.Test;

public class PublicTests {

	@Test
	public void testBasicConstructorsAndGetters() {

		MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7);
		MyDouble d = new MyDouble(555.729);

		ComplexNumber x = new ComplexNumber(a, b);
		assertTrue(x.getReal().compareTo(a) == 0 && x.getImag().compareTo(b) == 0);

		ComplexNumber z = new ComplexNumber(d);
		assertTrue(z.getReal().compareTo(d) == 0 && z.getImag().compareTo(new MyDouble(0)) == 0);
	}

	@Test
	public void testCopyConstructor() {

		MyDouble a = new MyDouble(5.7), b = new MyDouble(-3.7);

		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(x);
		assertTrue(x != y); // Check to be sure they are not aliased!
		assertTrue(y.getReal().compareTo(a) == 0 && y.getImag().compareTo(b) == 0);
	}

	@Test
	public void testAdd() {
		final MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7), c = new MyDouble(-5.7), d = new MyDouble(-3.7),e = new MyDouble(0);
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		ComplexNumber z = new ComplexNumber(e, e);
		ComplexNumber f = x.add(y);
		assertTrue(f.getReal().equals(z.getReal()) && f.getImag().equals(z.getImag()));
		assertTrue(f.getReal().equals(new MyDouble(0)) && f.getImag().equals(new MyDouble(0)));
	}

	@Test
	public void testSubtract() {
		final MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7), c = new MyDouble(-5.7), d = new MyDouble(-3.7);

		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		ComplexNumber g = x.subtract(y);

		assertTrue(g.getReal().equals(new MyDouble(11.4)) && g.getImag().equals(new MyDouble(7.4)));
	}

	@Test
	public void testMult() {
		final MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7), c = new MyDouble(-5.7), d = new MyDouble(-3.7);
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		ComplexNumber g = x.multiply(y);

		assertTrue(g.getReal().equals(new MyDouble(-18.8)) && g.getImag().equals(new MyDouble(-42.18)));
	}

	@Test
	public void testDiv() {
		final MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7), c = new MyDouble(-5.7), d = new MyDouble(-3.7);
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		ComplexNumber g = x.divide(y);

		assertTrue(g.getReal().equals(new MyDouble(-1)) && g.getImag().equals(new MyDouble(0)));
	}

	@Test
	public void testEqComp() {
		final MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7), c = new MyDouble(-5.7), d = new MyDouble(-3.7);
		ComplexNumber x = new ComplexNumber(a, b);
		ComplexNumber y = new ComplexNumber(c, d);
		assertTrue(!x.equals(y));
		y = new ComplexNumber(a, b);
		assertTrue(x.equals(y));
		assertTrue(x.compareTo(y) == 0);
		y = new ComplexNumber(c, c);
		assertTrue(!(x.compareTo(y) == 0));
	}

	//@Test
	//public void testToString() {
		//final MyDouble a = new MyDouble(5.7), b = new MyDouble(3.7);
		//ComplexNumber x = new ComplexNumber(a, b);
		// System.out.print(x);
		// System.out.print("5.7+3.7i");
	//}

	@Test
	public void testParse() {

		assertTrue(ComplexNumber.parseComplexNumber("    -127 - 1 233i")
				.equals(new ComplexNumber(new MyDouble(-127), new MyDouble(-1233))));
		assertTrue(ComplexNumber.parseComplexNumber("-1233333 + 12333i")
				.equals(new ComplexNumber(new MyDouble(-1233333), new MyDouble(12333))));
		assertTrue(ComplexNumber.parseComplexNumber(" 127 - 1 233i")
				.equals(new ComplexNumber(new MyDouble(127), new MyDouble(-1233))));
		assertTrue(ComplexNumber.parseComplexNumber("  127 + 1 233i")
				.equals(new ComplexNumber(new MyDouble(127), new MyDouble(1233))));

		
	}
	@Test
	public void testDivergence() {
		MyDouble a = new MyDouble(2), b = new MyDouble(0);
		ComplexNumber c = new ComplexNumber(a,b);	
		assertTrue(MandelbrotTools.divergence(c)==1);
		ComplexNumber d = new ComplexNumber(new MyDouble(-1.001),new MyDouble(1.0001));	
		ComplexNumber f = new ComplexNumber(new MyDouble(0),new MyDouble(0));
		assertTrue(MandelbrotTools.divergence(f)==-1);
		assertTrue(MandelbrotTools.divergence(d)==9);
		b = new MyDouble(-2);
		c = new ComplexNumber(a,b);
		assertTrue(MandelbrotTools.divergence(c)==0);
	}
}
